import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#1c1220',
        surface: '#241720',
        line: '#4a3348',
        muted: '#c9a8b3',
        faint: '#6e5a68',
        cream: '#f5ece6',
        gold: '#e0a458',
        goldLight: '#eab671',
        rose: '#e07a7a',
      },
      fontFamily: {
        serif: ['var(--font-serif)', 'serif'],
        sans: ['var(--font-sans)', 'sans-serif'],
      },
    },
  },
  plugins: [],
};

export default config;
