import Anthropic from '@anthropic-ai/sdk';
import { NextResponse } from 'next/server';

export const runtime = 'nodejs';

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const TONE_LABELS: Record<string, string> = {
  charming: 'charmoso e gentil',
  witty: 'engraçado e espirituoso',
  bold: 'confiante e direto, sem ser vulgar',
  casual: 'descontraído e natural',
};

export async function POST(req: Request) {
  // Optional shared-password protection so a public free deploy
  // doesn't let strangers spend your Anthropic credits.
  const requiredCode = process.env.ACCESS_CODE;
  if (requiredCode) {
    const providedCode = req.headers.get('x-access-code');
    if (providedCode !== requiredCode) {
      return NextResponse.json({ error: 'Código de acesso inválido.' }, { status: 401 });
    }
  }

  if (!process.env.ANTHROPIC_API_KEY) {
    return NextResponse.json(
      { error: 'ANTHROPIC_API_KEY não configurada no servidor.' },
      { status: 500 },
    );
  }

  try {
    const body = await req.json();
    const { image, text, tone, context } = body as {
      image?: string;
      text?: string;
      tone?: string;
      context?: string;
    };

    if (!image && !text) {
      return NextResponse.json(
        { error: 'Envie um print ou cole o texto da conversa.' },
        { status: 400 },
      );
    }

    const toneLabel = TONE_LABELS[tone ?? 'charming'] ?? TONE_LABELS.charming;

    const systemPrompt = `Você é "Estalo", um assistente que sugere respostas para conversas de paquera/relacionamento.

Regras:
- Detecte o idioma da conversa enviada e escreva as sugestões nesse mesmo idioma.
- Tom desejado para as respostas: ${toneLabel}.
- Cada sugestão deve ter no máximo 2 frases curtas, soando como uma pessoa real digitando, não como um robô.
- Nunca produza conteúdo sexual explícito, gráfico ou vulgar, mesmo com tom "ousado" — seja confiante e sedutor sem cruzar para o explícito.
- Não inclua saudações, explicações ou comentários fora das sugestões.
- Responda SOMENTE com um array JSON válido contendo exatamente 3 strings, e nada mais. Exemplo do formato: ["resposta 1", "resposta 2", "resposta 3"]${
      context ? `\n\nContexto adicional fornecido pelo usuário: ${context}` : ''
    }`;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const contentBlocks: any[] = [];

    if (image) {
      const match = image.match(/^data:(image\/[a-zA-Z]+);base64,(.+)$/);
      if (!match) {
        return NextResponse.json({ error: 'Formato de imagem inválido.' }, { status: 400 });
      }
      const [, mediaType, base64Data] = match;
      contentBlocks.push({
        type: 'image',
        source: { type: 'base64', media_type: mediaType, data: base64Data },
      });
      contentBlocks.push({
        type: 'text',
        text: 'Aqui está o print da conversa. Sugira as próximas respostas que eu poderia enviar.',
      });
    }

    if (text) {
      contentBlocks.push({
        type: 'text',
        text: `Aqui está o texto da conversa:\n\n${text}\n\nSugira as próximas respostas que eu poderia enviar.`,
      });
    }

    const response = await anthropic.messages.create({
      model: 'claude-sonnet-5',
      max_tokens: 1024,
      system: systemPrompt,
      messages: [{ role: 'user', content: contentBlocks }],
    });

    const textBlock = response.content.find((block) => block.type === 'text');
    const raw = textBlock && 'text' in textBlock ? textBlock.text : '[]';

    let suggestions: string[];
    try {
      const parsed = JSON.parse(raw);
      suggestions = Array.isArray(parsed) ? parsed : [];
    } catch {
      suggestions = raw
        .split('\n')
        .map((line: string) => line.replace(/^[-*\d.\s"]+|[",]+$/g, '').trim())
        .filter(Boolean)
        .slice(0, 3);
    }

    return NextResponse.json({ suggestions });
  } catch (err) {
    console.error('generate-reply error:', err);
    return NextResponse.json({ error: 'Algo deu errado ao gerar as respostas.' }, { status: 500 });
  }
}
