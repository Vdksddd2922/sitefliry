'use client';

import { useRef, useState } from 'react';

type Tone = 'charming' | 'witty' | 'bold' | 'casual';

const TONES: { id: Tone; label: string }[] = [
  { id: 'charming', label: 'Charmoso' },
  { id: 'witty', label: 'Engraçado' },
  { id: 'bold', label: 'Ousado' },
  { id: 'casual', label: 'Descontraído' },
];

function resizeImage(file: File, maxDim = 1200): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new window.Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > maxDim || height > maxDim) {
          const scale = maxDim / Math.max(width, height);
          width = Math.round(width * scale);
          height = Math.round(height * scale);
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas indisponível'));
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', 0.85));
      };
      img.onerror = () => reject(new Error('Não foi possível ler a imagem'));
      img.src = reader.result as string;
    };
    reader.onerror = () => reject(new Error('Não foi possível ler o arquivo'));
    reader.readAsDataURL(file);
  });
}

export default function Home() {
  const [mode, setMode] = useState<'image' | 'text'>('image');
  const [imageData, setImageData] = useState<string | null>(null);
  const [imageLabel, setImageLabel] = useState('');
  const [manualText, setManualText] = useState('');
  const [tone, setTone] = useState<Tone>('charming');
  const [context, setContext] = useState('');
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [error, setError] = useState('');
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  async function handleFile(file: File) {
    setError('');
    setImageLabel(file.name);
    try {
      const resized = await resizeImage(file);
      setImageData(resized);
    } catch {
      setError('Não foi possível processar essa imagem. Tente outro arquivo.');
    }
  }

  async function handleGenerate() {
    setError('');
    setSuggestions([]);

    if (mode === 'image' && !imageData) {
      setError('Envie um print da conversa primeiro.');
      return;
    }
    if (mode === 'text' && !manualText.trim()) {
      setError('Cole o texto da conversa primeiro.');
      return;
    }

    setLoading(true);
    const accessCode = typeof window !== 'undefined' ? localStorage.getItem('estalo-access-code') || '' : '';

    try {
      const res = await fetch('/api/generate-reply', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-access-code': accessCode,
        },
        body: JSON.stringify({
          image: mode === 'image' ? imageData : undefined,
          text: mode === 'text' ? manualText : undefined,
          tone,
          context: context.trim() || undefined,
        }),
      });

      if (res.status === 401) {
        const entered = window.prompt('Este app está protegido. Digite o código de acesso:');
        if (entered) {
          localStorage.setItem('estalo-access-code', entered);
          setError('Código salvo — toque em "Gerar respostas" de novo.');
        } else {
          setError('Código de acesso necessário.');
        }
        setLoading(false);
        return;
      }

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erro ao gerar respostas.');
      setSuggestions(data.suggestions || []);
    } catch (e: unknown) {
      const message = e instanceof Error ? e.message : 'Erro ao gerar respostas.';
      setError(message);
    } finally {
      setLoading(false);
    }
  }

  function copyToClipboard(text: string, index: number) {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedIndex(index);
      setTimeout(() => setCopiedIndex(null), 1500);
    });
  }

  return (
    <main className="min-h-screen px-4 py-10 sm:py-16">
      <div className="mx-auto max-w-lg">
        <header className="mb-8 text-center">
          <div className="mb-1 flex items-center justify-center gap-2">
            <span className="text-2xl text-gold">✦</span>
            <h1 className="font-serif text-4xl italic tracking-tight text-gold">Estalo</h1>
          </div>
          <p className="text-sm text-muted">seu wingman pra achar a resposta certa</p>
        </header>

        {/* Mode switch */}
        <div className="mb-6 flex rounded-full bg-surface p-1">
          <button
            type="button"
            onClick={() => setMode('image')}
            className={`flex-1 rounded-full py-2 text-sm font-medium transition ${
              mode === 'image' ? 'bg-gold text-ink' : 'text-muted'
            }`}
          >
            📸 Print
          </button>
          <button
            type="button"
            onClick={() => setMode('text')}
            className={`flex-1 rounded-full py-2 text-sm font-medium transition ${
              mode === 'text' ? 'bg-gold text-ink' : 'text-muted'
            }`}
          >
            💬 Texto
          </button>
        </div>

        {/* Input area */}
        {mode === 'image' ? (
          <div
            onClick={() => fileInputRef.current?.click()}
            onDragOver={(e) => {
              e.preventDefault();
              setDragActive(true);
            }}
            onDragLeave={() => setDragActive(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragActive(false);
              const file = e.dataTransfer.files?.[0];
              if (file) handleFile(file);
            }}
            className={`mb-6 flex h-44 cursor-pointer flex-col items-center justify-center overflow-hidden rounded-2xl border-2 border-dashed bg-surface text-center transition ${
              dragActive ? 'border-gold' : 'border-line'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
            />
            {imageData ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={imageData} alt={imageLabel} className="h-full w-full object-contain p-2" />
            ) : (
              <>
                <span className="mb-1 text-2xl">⬆️</span>
                <p className="px-4 text-sm text-muted">Toque ou arraste o print da conversa</p>
              </>
            )}
          </div>
        ) : (
          <textarea
            value={manualText}
            onChange={(e) => setManualText(e.target.value)}
            placeholder="Cole aqui a conversa..."
            rows={6}
            className="mb-6 w-full rounded-2xl border border-line bg-surface p-4 text-sm placeholder:text-faint focus:border-gold focus:outline-none"
          />
        )}

        {/* Tone selector */}
        <div className="mb-6">
          <p className="mb-2 text-xs uppercase tracking-wide text-muted">Tom da resposta</p>
          <div className="flex flex-wrap gap-2">
            {TONES.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTone(t.id)}
                className={`rounded-full border px-4 py-1.5 text-sm transition ${
                  tone === t.id ? 'border-gold bg-gold/10 text-gold' : 'border-line text-muted'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {/* Extra context */}
        <input
          value={context}
          onChange={(e) => setContext(e.target.value)}
          placeholder="Algo que a IA devia saber? (opcional)"
          className="mb-6 w-full rounded-2xl border border-line bg-surface p-3 text-sm placeholder:text-faint focus:border-gold focus:outline-none"
        />

        <button
          type="button"
          onClick={handleGenerate}
          disabled={loading}
          className="mb-8 w-full rounded-2xl bg-gold py-3 font-medium text-ink transition hover:bg-goldLight disabled:opacity-50"
        >
          {loading ? 'Gerando...' : '✦ Gerar respostas'}
        </button>

        {error && <p className="mb-4 text-center text-sm text-rose">{error}</p>}

        {suggestions.length > 0 && (
          <div className="space-y-3">
            {suggestions.map((s, i) => (
              <button
                key={i}
                type="button"
                onClick={() => copyToClipboard(s, i)}
                className="w-full rounded-2xl border border-line bg-surface p-4 text-left text-sm transition hover:border-gold"
              >
                <p>{s}</p>
                <p className="mt-2 text-xs text-gold">{copiedIndex === i ? '✓ copiado' : 'toque para copiar'}</p>
              </button>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
